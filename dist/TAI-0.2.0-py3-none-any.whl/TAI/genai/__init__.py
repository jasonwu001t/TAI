# genai/__init__.py
from .genai import GenAI,AWSBedrock

__all__ = [
    'GenAI',
    'AWSBedrock'
]
